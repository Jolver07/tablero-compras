# Tablero de cumplimiento de compras – NATURISA

Tablero web estático (HTML + JavaScript, sin servidor) con:

- Cumplimiento: OC cerradas con ingreso total ÷ OC aprobadas vigentes.
- OC abiertas vencidas y por vencer (días vencidos o por vencer; umbral configurable, 3 días por defecto).
- Ciclo de OC cerradas: SOLPED → último ingreso a bodega.
- Etapas del ciclo: aprob. cantidad, cotización, aprob. precio, aprobador OC1, aprobador OC2, generación OC, ingreso bodega.
- Ciclos en curso (no cerrados).
- Resumen por sucursal, tipo de solicitud, clúster y categoría.
- Filtros dinámicos: sucursal, tipo de solicitud, clúster, categoría (material/servicio/activo) y rango de fechas de SOLPED.
- Filtro por **número de SOLPED** (uno o varios, completos o parciales: `SP202604-00941, 00942`).
- **Datos en línea**: cualquiera que abra el enlace ve los datos publicados, sin cargar nada.
- El administrador actualiza los datos desde el mismo tablero: **Cargar reporte nuevo → Publicar para todos** (con clave).

## Estructura

```
tablero-compras/
├── public/                  ← carpeta que publica Cloudflare Pages
│   ├── index.html           ← el tablero
│   ├── data.json            ← datos precargados (se genera con el script)
│   ├── _headers             ← cabeceras de seguridad y caché
│   └── robots.txt           ← evita que buscadores indexen el sitio
├── functions/
│   └── api/datos.js         ← guarda y entrega los datos publicados (Cloudflare KV)
├── scripts/
│   └── generar_datos.py     ← convierte el Excel de SAP en public/data.json
├── requirements.txt
└── .gitignore               ← impide subir los .xlsx originales
```

## 1. Subir a GitHub

1. Cree un repositorio **privado** en GitHub (por ejemplo `tablero-compras`).
2. Suba el contenido de esta carpeta. Desde la web de GitHub: *Add file → Upload files* y arrastre las carpetas `public`, `scripts` y los archivos de la raíz. O con git:

   ```bash
   cd tablero-compras
   git init
   git add .
   git commit -m "Tablero de cumplimiento de compras"
   git branch -M main
   git remote add origin https://github.com/<usuario-u-organizacion>/tablero-compras.git
   git push -u origin main
   ```

## 2. Publicar en Cloudflare Pages

1. En el panel de Cloudflare: **Workers & Pages → Create → Pages → Connect to Git**.
2. Autorice GitHub y elija el repositorio `tablero-compras`.
3. Configuración de compilación:
   - **Framework preset:** None
   - **Build command:** (vacío)
   - **Build output directory:** `public`
4. **Save and Deploy**. En uno o dos minutos queda en `https://tablero-compras.pages.dev` (o el nombre que elija).

Cada vez que se haga un *push* a `main`, Cloudflare vuelve a publicar automáticamente.

### 2.1 Activar la publicación de datos desde el tablero (una sola vez)

1. **Workers & Pages → KV → Create namespace** → nombre `tablero-compras-datos`.
2. En el proyecto de Pages: **Settings → Bindings → Add → KV namespace**
   - Variable name: `DATOS` (exactamente así)
   - KV namespace: `tablero-compras-datos`
   - Agréguelo para *Production* (y *Preview* si la usa).
3. **Settings → Variables and Secrets → Add** → tipo **Secret**, nombre `ADMIN_KEY`, valor: una clave larga que solo conozca el administrador.
4. **Deployments → … → Retry deployment** para que tome la configuración.

Comprobación: `https://tablero-compras.pages.dev/api/datos` debe responder “Sin datos publicados” (antes de la primera publicación) en lugar de la página del tablero.

Si no configura el KV, el tablero sigue funcionando con `public/data.json` del repositorio.

## 3. Restringir el acceso (muy recomendado)

`data.json` contiene proveedores y OC de la empresa (no incluye precios ni valores). Un sitio de Pages es **público** por defecto.
Protéjalo con **Cloudflare Access** (Zero Trust, gratuito hasta 50 usuarios):

1. **Zero Trust → Access → Applications → Add an application → Self-hosted**.
2. Dominio de la aplicación: `tablero-compras.pages.dev` (y su dominio propio si lo agrega).
3. Política **Allow** → *Emails ending in* `@naturisa.com.ec` (o la lista de correos autorizados).
4. Método de ingreso: *One-time PIN* por correo (no requiere configurar nada más).

Además, en el proyecto de Pages: **Settings → General → Access policy → Enable** protege las vistas previas de cada despliegue.

Con Access activo, quien tenga el enlace ingresa su correo, recibe un código y ve el tablero con los datos ya cargados.

## 4. Actualizar los datos

### Opción A – desde el tablero (recomendada, sin GitHub ni Python)

1. Abra el tablero y presione **Cargar reporte nuevo**; elija el Excel “Seguimiento de Solpeds” (tarda 20–40 s con 25 MB).
2. Revise los datos. Aparece la barra **“Publicar para todos”**: escriba la clave `ADMIN_KEY` y presione el botón.
3. Desde ese momento todos los que abran el enlace ven el reporte nuevo (la propagación puede tardar hasta 1 minuto).

Los visitantes nunca necesitan cargar nada: el tablero lee primero los datos publicados (`/api/datos`) y, si no hay, usa `public/data.json`.
Si alguien sin clave usa **Cargar reporte nuevo**, el cambio solo se ve en su navegador.

### Opción B – por GitHub

Con Python 3.10 o superior:

```bash
pip install -r requirements.txt
python scripts/generar_datos.py "C:\Descargas\Seguimiento de Solpeds - 2026-10-05.xlsx"
git add public/data.json
git commit -m "Datos al 05/10/2026"
git push
```

- La fecha de corte se toma de la fecha más reciente del reporte; para fijarla: `--corte 2026-10-05`.
- Cloudflare Pages admite archivos de hasta 25 MB; con ~83.000 líneas `data.json` pesa ~10 MB.
- El Excel original no se sube (lo bloquea `.gitignore`).

Si usa la opción A, los datos publicados desde el tablero tienen prioridad sobre `public/data.json`.

## Columnas requeridas del reporte

`Estado, Solped, Clúster, Sucursal, Tipo Solicitud, Categoría, Comprador(a), Proveedor, Código, Nombre de Item,
Fecha solped., Fecha Aprob, Fecha atención comprador, Fecha Preorden, Fecha Aprob Precio, Fecha Aprob 1 OC,
Fecha Aprob 2 OC, Fecha OC, OC ERP, Fecha de entrega, Ult. Fecha Ingr. Bod, Cant. Orden Compra, Cant. Ingreso,
Cantidad Pendiente`

## Definiciones principales

| Indicador | Cálculo |
|---|---|
| Cumplimiento | OC con todas sus posiciones no anuladas en “OC CERRADA (IT)” ÷ OC aprobadas (sin anuladas) |
| Vencida / por vencer | Fecha de entrega comprometida vs. fecha de corte; por vencer = vence en ≤ N días |
| Atención | Aprobación de la SOLPED → generación de la OC (no incluye ingreso a bodega) |
| Ciclo total | Fecha de SOLPED → último ingreso a bodega, solo OC cerradas con ingreso total |
| Etapas del ciclo | Diferencias entre fechas y horas de cada hito, por posición de OC cerrada con ingreso total |
| % atención | Líneas de SOLPED aprobadas con OC no anulada o contrato ÷ líneas aprobadas |

Días calendario. Librerías externas cargadas desde CDN: SheetJS (lectura de Excel, cdnjs) y fuentes IBM Plex (Google Fonts).
